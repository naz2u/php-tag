<?php

if(isset($_POST['submit'])){
	$username = $_POST['username'];
	$password = $_POST['pswd'];

	$db = new mysqli("localhost", "root", "", "webuser");

	$data = "SELECT * FROM users WHERE username='$username' AND password='$password'";
	$result = $db->query($data);
	
	if(mysqli_num_rows($result)>0){	
		echo "Valide User.";
	}else{
		echo "Invalide User.";
	}
}

?>

<form method="POST" action="#">
	Username: <input type="text" name="username" /></br></br>
	Password: <input type="password" name="pswd" /></br></br>
			  <input type="submit" name="submit" value="Login" />
</form>









